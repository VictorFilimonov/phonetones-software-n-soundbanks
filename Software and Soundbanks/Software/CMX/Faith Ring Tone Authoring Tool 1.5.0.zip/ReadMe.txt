********************************************************************
Ring Tone Authoring Tool

Copyright (C) 2003-2004 Faith, Inc. 

9/10/2004
********************************************************************

[Version]

  Ring Tone Authoring Tool Version 1.5.0


[File Structure]

  Tool/
       RTConverter.exe          Ring Tone Converter Execution File
       RTPlayer.exe             Ring Tone Player Execution File
       rt_smf2mfmp.exe          SMF to MFMP Converter Execution File
       rt_smf2iMelody.exe       SMF to iMelody Converter Execution File
       rt_wav2mfmp.exe          WAVE to MFMP Converter Execution File
       rt_mcomp_encode.exe      M-Compression Converter Exeuction File
       UCSEditorF.exe           UCS Editor F 
       UCSEditorR.exe           UCS Editor R 
  
   Sample/
       SMF Sample Data
       MFMP Sample Data
       MIDI Setup File
       Each Format Sample Data after Conversion

  Documents/
      AuthoringTool_E.pdf       Ring Tone Authoring Tool Guideline
      RTConverter_E.pdf         Ring Tone Converter Manual
      RTPlayer_E.pdf            Ring Tone Player Manual
      SMFtoMFMP_E.pdf           SMF to MFMP Converter Manual
      WAVEtoMFMP_E.pdf          WAVE to MFMP Converter Manual
      SMFtoiMelody_E.pdf        SMF to iMelody Converter Manual
      MCompression_E.pdf        M-Compression Converter Manual
      MIDISetup_E.pdf           MIDI Message Setup File Guideline
      UCSEditorFManual_E.pdf    UCS Editor F User's Manual
      UCSEditorRManual_E.pdf    UCS Editor R User's Manual
      ConProduction_E.pdf       Content Production Guideline
      MonoProduction_E.pdf      Monophonic Production Guideline

      History.txt   Change History
      ReadMe.txt    This File


[System Requirements]

CPU  : Pentium II 200MHz or higher processor (Pentium III 450MHz or higher processor recommended)
Memory   : 64MB or more (128MB or more recommended)
OS   : Windows98, Windows 98SE, Windows ME, WIndows 2000, Windows XP
HD Space : 20MB or more is required for installation
      * Additional HD space is required for data production.
