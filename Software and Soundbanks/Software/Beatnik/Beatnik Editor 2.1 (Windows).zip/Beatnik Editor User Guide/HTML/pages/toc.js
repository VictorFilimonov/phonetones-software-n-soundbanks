// Copyright (c) 1999 Quadralay Corporation.  All rights reserved.
//
// The information in this file is confidential and proprietary to
// Quadralay Corporation.  Unauthorized use or duplication is
// strictly prohibited.

hsmod[hsmod.length]="Beatnik Editor User Guide";

var wwhtop = foldersTree;

wwhtop.addChild(new Item("Introduction", "introduc.htm#top"));
var wwh792220=new Folder("Getting Started", "gettings.htm#top");
wwhtop.addChild(wwh792220);

wwh792220.addChild(new Item("Installing the Beatnik Editor", "getting2.htm#top"));
wwh792220.addChild(new Item("Registering the Beatnik Editor", "getting3.htm#top"));
wwh792220.addChild(new Item("Using the Beatnik Editor", "getting4.htm#top"));
wwh792220.addChild(new Item("How Do I...", "gettin11.htm#top"));
var wwh792219=new Folder("For Musicians", "formusic.htm#top");
wwhtop.addChild(wwh792219);

wwh792219.addChild(new Item("Orientation", "formusi2.htm#top"));
wwh792219.addChild(new Item("The Beatnik MIDI Playback Sequencer", "formusi3.htm#top"));
wwh792219.addChild(new Item("The Beatnik MIDI Synthesizer", "formusi4.htm#top"));
wwh792219.addChild(new Item("Production Technique Tips", "formus14.htm#top"));
wwh792219.addChild(new Item("Linking to your Sequencer", "linktose.htm#top"));
var wwh794322=new Folder("Advanced Techniques", "advanced.htm#top");
wwhtop.addChild(wwh794322);

wwh794322.addChild(new Item("Triggerable Sample Banks (RMFX)", "advance2.htm#top"));
wwh794322.addChild(new Item("Automatic Looping and Track Muting", "advance3.htm#top"));
wwh794322.addChild(new Item("MIDI Channel Modes", "advance4.htm#top"));
var wwh792205=new Folder("For Reference", "forrefer.htm#top");
wwhtop.addChild(wwh792205);

wwh792205.addChild(new Item("FAQ", "faq.htm#top"));
wwh792205.addChild(new Item("Menu Reference", "menusref.htm#top"));
wwh792205.addChild(new Item("Window Reference", "windowsr.htm#top"));
wwh792205.addChild(new Item("Troubleshooting", "troubles.htm#top"));
wwh792205.addChild(new Item("Removing the Beatnik Editor", "removing.htm#top"));
wwh792205.addChild(new Item("Compatibility Information", "compatib.htm#top"));
wwh792205.addChild(new Item("Versions and Updates", "versions.htm#top"));
wwh792205.addChild(new Item("License Agreement", "license.htm#top"));
wwh792205.addChild(new Item("Online Resources", "onlinere.htm#top"));
wwh792205.addChild(new Item("Built-In Instruments", "builtini.htm#top"));
wwh792205.addChild(new Item("Live MIDI Input", "livemidi.htm#top"));

