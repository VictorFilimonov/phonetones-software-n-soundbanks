// Copyright (c) 1999 Quadralay Corporation.  All rights reserved.
//
// The information in this file is confidential and proprietary to
// Quadralay Corporation.  Unauthorized use or duplication is
// strictly prohibited.


